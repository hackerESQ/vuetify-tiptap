import { Extension } from '@tiptap/core'

export default Extension.create<FullscreenOptions>({
  name: 'fullscreen'
})
